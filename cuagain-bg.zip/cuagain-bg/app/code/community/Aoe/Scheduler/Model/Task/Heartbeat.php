<?php

/**
 * Class Aoe_Scheduler_Model_HeartbeatTask
 *
 * @author Fabrizio Branca
 */
class Aoe_Scheduler_Model_Task_Heartbeat
{

    public function run()
    {
        return true;
    }
}
