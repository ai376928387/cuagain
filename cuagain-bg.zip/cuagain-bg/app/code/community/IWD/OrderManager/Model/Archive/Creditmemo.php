<?php
class IWD_OrderManager_Model_Archive_Creditmemo extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('iwd_ordermanager/archive_creditmemo');
    }
}